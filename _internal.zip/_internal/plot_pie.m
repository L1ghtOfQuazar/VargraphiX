pie([1.0],{'Джон Смит'})
legend({'Джон Смит'})
title('Имя')
pause